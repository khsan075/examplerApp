#
# COPYRIGHT Ericsson 2023
#
#
#
# The copyright to the computer program(s) herein is the property of
#
# Ericsson Inc. The programs may be used and/or copied only with written
#
# permission from Ericsson Inc. or in accordance with the terms and
#
# conditions stipulated in the agreement/contract under which the
#
# program(s) have been supplied.
#

from eiid_access_id import network_configuration_url_helper
from eiid_access_id.network_configuration_url_helper import NetworkConfigurationUrlData
from eiid_access_id.network_configuration_url_helper import DataStoreType
import unittest
import urllib.parse

EXPECTED_EXTERNALID_REFDATA = NetworkConfigurationUrlData(
    cmhandleId = "55285C5727D6F18DF3FBCB6D1AF58591",
    resourceId = "/ericsson-enm-ComTop:ManagedElement[@id=NR01gNodeBRadio00007]/ericsson-enm-GNBDU:GNBDUFunction[@id=1]/ericsson-enm-GNBDU:NRCellDU[@id=NR01gNodeBRadio00007-1]",
    baseUrl = "",
    datastoreType = DataStoreType.PASSTHROUGH_OPERATIONAL)

EXPECTED_PREFIXED_FDN_REFDATA = NetworkConfigurationUrlData(
    cmhandleId = "B3A556D0ACFBF33077B3C297D90BB297",
    resourceId = "/ManagedElement[@id=NR01gNodeBRadio00007]/GNBDUFunction[@id=1]/NRCellDU[@id=NR01gNodeBRadio00007-1]",
    baseUrl = "",
    datastoreType = DataStoreType.PASSTHROUGH_OPERATIONAL)

EXPECTED_FDN_REFDATA = NetworkConfigurationUrlData(
    cmhandleId = "55285C5727D6F18DF3FBCB6D1AF58591",
    resourceId = "/ManagedElement[@id=NR01gNodeBRadio00007]/GNBDUFunction[@id=1]/NRCellDU[@id=NR01gNodeBRadio00007-1]",
    baseUrl = "",
    datastoreType = DataStoreType.PASSTHROUGH_OPERATIONAL)

class TestExternalUtilMethods(unittest.TestCase):

    def test_reference_data_from_external_id(self) :
        external_id = "55285C5727D6F18DF3FBCB6D1AF58591/ericsson-enm-ComTop:ManagedElement=NR01gNodeBRadio00007/ericsson-enm-GNBDU:GNBDUFunction=1/ericsson-enm-GNBDU:NRCellDU=NR01gNodeBRadio00007-1"
        got = network_configuration_url_helper.url_data_from_external_id(external_id)
        expectedUrl = "/ncmp/v1/ch/55285C5727D6F18DF3FBCB6D1AF58591/data/ds/ncmp-datastore:passthrough-operational?resourceIdentifier=" + urllib.parse.quote("/ericsson-enm-ComTop:ManagedElement[@id=NR01gNodeBRadio00007]/ericsson-enm-GNBDU:GNBDUFunction[@id=1]/ericsson-enm-GNBDU:NRCellDU[@id=NR01gNodeBRadio00007-1]", safe="")
        self.assertEqual( EXPECTED_EXTERNALID_REFDATA.cmhandleId , got.cmhandleId)
        self.assertEqual( EXPECTED_EXTERNALID_REFDATA.resourceId , got.resourceId)
        self.assertEqual( EXPECTED_EXTERNALID_REFDATA.baseUrl , got.baseUrl)
        self.assertEqual( EXPECTED_EXTERNALID_REFDATA.datastoreType , got.datastoreType)
        self.assertEqual( expectedUrl , got.get_network_configuration_url())

    def test_reference_data_from_prefixed_fdn(self) :
        prefixed_fdn = "urn:3gpp:dn:ManagedElement=NR01gNodeBRadio00007,GNBDUFunction=1,NRCellDU=NR01gNodeBRadio00007-1"
        got = network_configuration_url_helper.url_data_from_prefixed_fdn(prefixed_fdn)
        expectedUrl = "/ncmp/v1/ch/B3A556D0ACFBF33077B3C297D90BB297/data/ds/ncmp-datastore:passthrough-operational?resourceIdentifier=" + urllib.parse.quote("/ManagedElement[@id=NR01gNodeBRadio00007]/GNBDUFunction[@id=1]/NRCellDU[@id=NR01gNodeBRadio00007-1]", safe="")
        self.assertEqual(EXPECTED_PREFIXED_FDN_REFDATA.cmhandleId, got.cmhandleId)
        self.assertEqual(EXPECTED_PREFIXED_FDN_REFDATA.resourceId, got.resourceId)
        self.assertEqual(EXPECTED_PREFIXED_FDN_REFDATA.baseUrl, got.baseUrl)
        self.assertEqual(EXPECTED_PREFIXED_FDN_REFDATA.datastoreType, got.datastoreType)
        self.assertEqual( expectedUrl , got.get_network_configuration_url())

    def test_reference_data_from_external_id_with_params(self) :
        external_id = "55285C5727D6F18DF3FBCB6D1AF58591/ericsson-enm-ComTop:ManagedElement=NR01gNodeBRadio00007/ericsson-enm-GNBDU:GNBDUFunction=1/ericsson-enm-GNBDU:NRCellDU=NR01gNodeBRadio00007-1"
        got =  network_configuration_url_helper.url_data_from_external_id(external_id, "", DataStoreType.PASSTHROUGH_OPERATIONAL)
        expectedUrl = "/ncmp/v1/ch/55285C5727D6F18DF3FBCB6D1AF58591/data/ds/ncmp-datastore:passthrough-operational?resourceIdentifier=" + urllib.parse.quote("/ericsson-enm-ComTop:ManagedElement[@id=NR01gNodeBRadio00007]/ericsson-enm-GNBDU:GNBDUFunction[@id=1]/ericsson-enm-GNBDU:NRCellDU[@id=NR01gNodeBRadio00007-1]", safe="")
        self.assertEqual( EXPECTED_EXTERNALID_REFDATA.cmhandleId , got.cmhandleId)
        self.assertEqual( EXPECTED_EXTERNALID_REFDATA.resourceId , got.resourceId)
        self.assertEqual( EXPECTED_EXTERNALID_REFDATA.baseUrl , got.baseUrl)
        self.assertEqual( EXPECTED_EXTERNALID_REFDATA.datastoreType , got.datastoreType)
        self.assertEqual( expectedUrl , got.get_network_configuration_url())

    def test_reference_data_from_prefixed_fdn_with_params(self) :
        prefixed_fdn = "urn:3gpp:dn:ManagedElement=NR01gNodeBRadio00007,GNBDUFunction=1,NRCellDU=NR01gNodeBRadio00007-1"
        got =  network_configuration_url_helper.url_data_from_prefixed_fdn(prefixed_fdn, "", DataStoreType.PASSTHROUGH_OPERATIONAL)
        expectedUrl = "/ncmp/v1/ch/B3A556D0ACFBF33077B3C297D90BB297/data/ds/ncmp-datastore:passthrough-operational?resourceIdentifier=" + urllib.parse.quote("/ManagedElement[@id=NR01gNodeBRadio00007]/GNBDUFunction[@id=1]/NRCellDU[@id=NR01gNodeBRadio00007-1]", safe="")
        self.assertEqual(EXPECTED_PREFIXED_FDN_REFDATA.cmhandleId, got.cmhandleId)
        self.assertEqual(EXPECTED_PREFIXED_FDN_REFDATA.resourceId, got.resourceId)
        self.assertEqual(EXPECTED_PREFIXED_FDN_REFDATA.baseUrl, got.baseUrl)
        self.assertEqual(EXPECTED_PREFIXED_FDN_REFDATA.datastoreType, got.datastoreType)
        self.assertEqual( expectedUrl , got.get_network_configuration_url())

    def test_reference_data_from_fdn(self) :
        nodeFdn = "SubNetwork=Europe,SubNetwork=Ireland,MeContext=NR01gNodeBRadio00007,ManagedElement=NR01gNodeBRadio00007,GNBDUFunction=1,NRCellDU=NR01gNodeBRadio00007-1"
        got = network_configuration_url_helper.url_data_from_fdn(nodeFdn)
        expectedUrl = "/ncmp/v1/ch/55285C5727D6F18DF3FBCB6D1AF58591/data/ds/ncmp-datastore:passthrough-operational?resourceIdentifier=" + urllib.parse.quote("/ManagedElement[@id=NR01gNodeBRadio00007]/GNBDUFunction[@id=1]/NRCellDU[@id=NR01gNodeBRadio00007-1]", safe="")
        self.assertEqual( EXPECTED_FDN_REFDATA.cmhandleId , got.cmhandleId)
        self.assertEqual( EXPECTED_FDN_REFDATA.resourceId , got.resourceId)
        self.assertEqual( EXPECTED_FDN_REFDATA.baseUrl , got.baseUrl)
        self.assertEqual( EXPECTED_FDN_REFDATA.datastoreType , got.datastoreType)
        self.assertEqual( expectedUrl , got.get_network_configuration_url())

    def test_reference_data_from_fdn_no_resource_id(self) :
        nodeFdn = "anything"
        got = network_configuration_url_helper.url_data_from_fdn(nodeFdn)
        expectedUrl = "/ncmp/v1/ch/AFEDCCCC6D1640B98E4573C9A147A34B/data/ds/ncmp-datastore:passthrough-operational?resourceIdentifier=" + urllib.parse.quote("/", safe="")
        self.assertEqual( "AFEDCCCC6D1640B98E4573C9A147A34B", got.cmhandleId)
        self.assertEqual( urllib.parse.quote("/", safe="") , got.resourceId)
        self.assertEqual( "" , got.baseUrl)
        self.assertEqual( DataStoreType.PASSTHROUGH_OPERATIONAL , got.datastoreType)
        self.assertEqual( expectedUrl , got.get_network_configuration_url())

    def test_reference_data_from_fdn_with_params(self) :
        nodeFdn = "SubNetwork=Europe,SubNetwork=Ireland,MeContext=NR01gNodeBRadio00007,ManagedElement=NR01gNodeBRadio00007,GNBDUFunction=1,NRCellDU=NR01gNodeBRadio00007-1"
        got = network_configuration_url_helper.url_data_from_fdn(nodeFdn, "", DataStoreType.PASSTHROUGH_OPERATIONAL)
        expectedUrl = "/ncmp/v1/ch/55285C5727D6F18DF3FBCB6D1AF58591/data/ds/ncmp-datastore:passthrough-operational?resourceIdentifier=" + urllib.parse.quote("/ManagedElement[@id=NR01gNodeBRadio00007]/GNBDUFunction[@id=1]/NRCellDU[@id=NR01gNodeBRadio00007-1]", safe="")
        self.assertEqual( EXPECTED_FDN_REFDATA.cmhandleId , got.cmhandleId)
        self.assertEqual( EXPECTED_FDN_REFDATA.resourceId , got.resourceId)
        self.assertEqual( EXPECTED_FDN_REFDATA.baseUrl , got.baseUrl)
        self.assertEqual( EXPECTED_FDN_REFDATA.datastoreType , got.datastoreType)
        self.assertEqual( expectedUrl , got.get_network_configuration_url())  

    def test_generate_cmhandle_id(self):
        res = network_configuration_url_helper.url_data_from_fdn("SubNetwork=Europe,SubNetwork=Ireland,MeContext=NR03gNodeBRadio00014,ManagedElement=NR03gNodeBRadio00014")
        expected = "F358402C53CD4E9C903F83DF6004ED8F"
        self.assertEqual( res.cmhandleId , expected )

    def test_generate_cmhandle_id_when_md5_hash_started_with_zero(self):
        res = network_configuration_url_helper.url_data_from_fdn("MeContext=cloud1513-vdu,ManagedElement=cloud1513-vdu")
        expected = "0A7E00DDA8975F0C834552488B76C106"
        self.assertEqual( res.cmhandleId , expected )

if __name__ == '__main__':
    unittest.main()