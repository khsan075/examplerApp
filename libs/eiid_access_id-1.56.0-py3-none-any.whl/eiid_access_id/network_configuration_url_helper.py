#
# COPYRIGHT Ericsson 2023
#
#
#
# The copyright to the computer program(s) herein is the property of
#
# Ericsson Inc. The programs may be used and/or copied only with written
#
# permission from Ericsson Inc. or in accordance with the terms and
#
# conditions stipulated in the agreement/contract under which the
#
# program(s) have been supplied.
#

from enum import Enum
import hashlib
import urllib.parse

PREFIXES_TIES = ["urn:3gpp:dn:"]

class DataStoreType(Enum):
    PASSTHROUGH_OPERATIONAL = "passthrough-operational"
    PASSTHROUGH_RUNNING = "passthrough-running"

class NetworkConfigurationUrlData:

    def __init__(self, cmhandleId, resourceId, baseUrl = "", datastoreType = DataStoreType.PASSTHROUGH_OPERATIONAL):
        self.cmhandleId = cmhandleId
        self.resourceId = urllib.parse.quote(resourceId, safe="")
        self.baseUrl = baseUrl
        self.datastoreType = datastoreType

    def get_network_configuration_url(self) -> str:
        return f"{self.baseUrl}/ncmp/v1/ch/{self.cmhandleId}/data/ds/ncmp-datastore:{self.datastoreType.value}?resourceIdentifier={self.resourceId}"

##################################################################################


def url_data_from_external_id(externalId: str, baseUrl: str = "", datastoreType: DataStoreType = DataStoreType.PASSTHROUGH_OPERATIONAL) -> NetworkConfigurationUrlData:
    externalElements = externalId.split("/", 1)
    cmhandle_id = externalElements[0]
    resource_id = __convertResourceId(externalElements[1])
    return NetworkConfigurationUrlData(cmhandle_id, resource_id, baseUrl, datastoreType)

def url_data_from_prefixed_fdn(externalId: str, baseUrl: str = "", datastoreType: DataStoreType = DataStoreType.PASSTHROUGH_OPERATIONAL) -> NetworkConfigurationUrlData:
    prefix = __identity_prefix(externalId)
    if prefix != "":
        fdnConcatenated = externalId.split(prefix, 2)
        return url_data_from_fdn(fdnConcatenated[1], baseUrl, datastoreType)
    return NetworkConfigurationUrlData("", "", baseUrl, datastoreType)


def url_data_from_fdn(fdn : str, baseUrl: str = "", datastoreType: DataStoreType = DataStoreType.PASSTHROUGH_OPERATIONAL) -> NetworkConfigurationUrlData:
    cmhandle_seed, resource_id_seed = __prepared_fdn_to_cmhandle_resource_id(fdn)
    cmhandle_id = __generate_cmhandle_id(cmhandle_seed)
    resource_id = __convertResourceId(resource_id_seed)
    return NetworkConfigurationUrlData(cmhandle_id, resource_id, baseUrl, datastoreType)

def __prepared_fdn_to_cmhandle_resource_id(fdn : str) -> (str, str):
    fdnElementArray = fdn.split(",")
    seedElements = []
    resourceIdElements = []
    seed = True
    possibleSharedCnfRoot = False
    for fdnPart in fdnElementArray :
        if fdnPart.startswith("ManagedElement") or fdnPart.startswith("RANInfrastructureSupport"):
            seed = False
            seedElements.append(fdnPart)
        # if MeContext has been added to the seed and not supported element arrives,
        # then this is the end of cmhandle seed
        if possibleSharedCnfRoot :
            seed = False
        if seed:
            seedElements.append(fdnPart)
        else :
            resourceIdElements.append(fdnPart)
        if fdnPart.startswith("MeContext") :
            possibleSharedCnfRoot = True
    return ",".join(seedElements) , "/".join(resourceIdElements)


def __convertResourceId(inputResourceId : str) -> str:
    tmp = "/" + inputResourceId.replace("=", "[@id=").replace("/", "]/")
    if tmp[-1] != "/":
        return tmp + "]"
    return tmp

def __generate_cmhandle_id(fdn : str) -> str:
    return hashlib.md5(("EricssonENMAdapter-" + fdn).encode('utf-8')).hexdigest().upper()

def __identity_prefix(fdn : str) -> str:
    for prefix in PREFIXES_TIES:
        if prefix in fdn:
            return prefix
    return ""
